export interface IEvents {
  eventId?: string,
  eventName?: string,
  eventDate?: string,
  eventPlace?: string
}
